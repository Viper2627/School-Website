var express = require("express"),
bodyParser  = require("body-parser"),
mongoose    = require("mongoose"),
passport    = require("passport"),
multer      = require("multer"),
GridFsStorage = require("multer-gridfs-storage"),
Grid        = require("gridfs-Stream"),
LocalStrategy = require("passport-local"),
User        = require("./models/user"),
app         = express();
var conn = mongoose.createConnection("mongodb://localhost/mainpage",{ useNewUrlParser: true,useUnifiedTopology: true });
mongoose.connect("mongodb://localhost/mainpage",{ useNewUrlParser: true,useUnifiedTopology: true });
 $ = require('jquery')
app.use(express.static("public"));
app.use(bodyParser.urlencoded({extended: true}));
app.set("view engine", "ejs");
app.use(require("express-session")({
    secret:"ramesh is hero",
    resave:false,
    saveUninitialized:false
}))
app.use(passport.initialize());
app.use(passport.session());
passport.use(new LocalStrategy(User.authenticate()));
passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());

let gfs;
conn.once('open',()=>{

    gfs = Grid(conn.db,mongoose.mongo);
})

const storage = new GridFsStorage({
    url:"mongodb://localhost/mainpage",
    file:(req,file) => {

        return new Promise((resolve,reject) =>{
            const filename = file.originalname;
            const fileinfo = {
                filename: filename,
                bucketname: 'uploads'
            };
            resolve(fileinfo);
        });
    }
});
const upload = multer({storage});
var anounce = new mongoose.Schema({
    inf : String,
    Created: {type:Date, default:Date.now}
})
app.post('/upload', upload.single('file'), (req, res) => {
    res.redirect('/gallery');
  });

var info = mongoose.model("info", anounce);

//info.create({
//inf: "hello"
//})

app.get("/",function(req,res) {
    res.redirect("/infos");
})
app.get("/gallery",(req,res)=>{
    gfs.files.find().toArray((err,files)=>{
        if(!files || files.length === 0){
            res.render("gallery",{files:false});}
            else{
                files.map(file =>{
                    if(
                        file.contentType === 'image/jpeg'||
                        file.contentType === 'image/png'
                    ){
                        file.isImage = true;

                    }
                    else{
                        file.isImage = false;
                    }
                });
                res.render("gallery",{files: files});
            }
        });
    });


app.get("/infos/info",function(req,res){
    res.render("detail");
})
app.post("/infos",function(req,res){
    info.create(req.body.infos,function(err,newindex){
        if(err){
            consolde.log("failed");
        }
        else{
            res.redirect("/infos");
        }
    })
})


app.get("/infos",function(req,res){
    info.find({},{},{sort:{'Created':-1}},function(err,infos){
        if(err){
            consolde.log("failed");
        }else{
            res.render("index",{infos: infos});
        }
    })
})

app.get("/register",function(req,res){
    res.render("register");
})

app.post("/register",function(req,res){
    var newuser = new User({username: req.body.username});
    User.register(newuser,req.body.password,function(err,user){
        if(err){
            res.render("register");
        }
        else{
            passport.authenticate("local")(req,res,function(){
                res.redirect("/infos");
            })
        }

    });

})

app.get("/auth",function(req,res){
    if(req.isAuthenticated()){
    
        res.render("user");
    }
else{
    console.log("login")
}
});
app.get("/login",function(req,res){
    res.render("login");
})
app.post("/login", passport.authenticate("local",{
    successRedirect:"/auth",
    failureRedirect: "/infos"
}),function(req,res){

   
})

app.get('/files/:filename', (req, res) => {
    gfs.files.findOne({ filename: req.params.filename }, (err, file) => {
      // Check if file
      if (!file || file.length === 0) {
        return res.status(404).json({
          err: 'No file exists'
        });
      }
      // If File exists this will get executed
      const readstream = gfs.createReadStream(file.filename);
      return readstream.pipe(res);
    });
  });
  app.get('/videos/:filename', (req, res) => {
    gfs.files.findOne({ filename: req.params.filename }, (err, file) => {

 
    res.header('Content-Length', file.length);
    res.header('Content-Type', file.contentType);

    gfs.createReadStream(
        file.filename
    );
    return pipe(res);

});});
  
  app.get('/image/:filename', (req, res) => {
    gfs.files.findOne({ filename: req.params.filename }, (err, file) => {
      // Check if the input is a valid image or not
      if (!file || file.length === 0) {
        return res.status(404).json({
          err: 'No file exists'
        });
      }
  
      // If the file exists then check whether it is an image
      if (file.contentType === 'image/jpeg' || file.contentType === 'image/png') {
        // Read output to browser
        const readstream = gfs.createReadStream(file.filename);
        readstream.pipe(res);
      } else {
        res.status(404).json({
          err: 'Not an image'
        });
      }
    });
  });
  
  // delete function to remove the file from the database
  app.delete('/files/:id', (req, res) => {
    gfs.remove({ _id: req.params.id, root: 'mainpage' }, (err, gridStore) => {
      if (err) {
        return res.status(404).json({ err: err });
      }
  
      res.redirect('/');
    });
  });
app.get("/logout",function(req,res){
    req.logOut()
    res.redirect("/infos")
})
app.listen(3000,'127.0.0.1');
    console.log("Successful");
    